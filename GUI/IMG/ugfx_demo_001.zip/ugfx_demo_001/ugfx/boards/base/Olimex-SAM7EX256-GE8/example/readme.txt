Copy these files into your own project directory and alter them to suite.
