This directory contains the interface for OSX using X.

On this board uGFX currently supports:
	- GDISP via the X driver
	- GINPUT-touch via the X driver

There is an example Makefile and project in the examples directory.
