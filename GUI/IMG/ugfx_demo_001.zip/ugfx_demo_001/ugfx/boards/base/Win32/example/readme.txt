Copy these files into your own project directory and alter them to suite.

Notes:

1/ This makefile uses the MINGW compiler tool chain and was run using the cygwin make.
2/ The files chconf.h and halconf.h are only needed if compiling for the ChibiOS simulator.
