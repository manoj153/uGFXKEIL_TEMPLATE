This directory contains the interface for eCos using a synthetic framebuffer display.



On this board uGFX currently supports:

	- GDISP via the framebuffer driver



There is an example Makefile and project in the examples directory.
