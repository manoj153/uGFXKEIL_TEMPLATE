Copy these files into your own project directory and alter them to suite.

Notes:

1/ Look at the MYFILES definition and the MYCSRC definition.
