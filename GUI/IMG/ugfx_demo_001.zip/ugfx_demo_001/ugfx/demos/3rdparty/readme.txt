In this directory, you can find different demos showing how to use ChibiOS/GFX.
The demos in these directories are contributions from users of the ChibiOS/GFX
project and come from different sources. Therefore, the source files of these
demos come with different licenses which can be found on top of the cor-
responding files.
Since these files are not part of the ChibiOS/GFX project, no support for these
demos is provided. And as with all software which can be found in the /demos
directory, use on your own risk. There's no warranty of the correctness
and function of the demos provided.

