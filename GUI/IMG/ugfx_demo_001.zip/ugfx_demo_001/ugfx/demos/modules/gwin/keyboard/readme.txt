This demo demonstrates the virtual keyboard.
