If there is no html directory containing the HTML version of the API documentation, you
can find an online version of the documentation at http://api.ugfx.org
